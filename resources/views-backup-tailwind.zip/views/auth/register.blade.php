<x-guest-layout>
    <div class="w-75 md:w-1/2 lg:w-1/3 mx-auto mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
    <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
        @csrf

        <div class="row">
            <div class="col-lg-6 col-sm-12 col-md-12">
        <!-- Name -->
        <div>
            <x-input-label for="name" :value="__('Name (اسم)')" />
            <div class="row">
                <div class=" col col-lg-2 col-sm-4 col-md-4">
                    <select class="form-control mt-1" name="surname">
                        <option value="Mr">Mr</option>
                        <option value="Mr">Mrs</option>
                        <option value="Mr">Ms</option>
                    </select>
                </div>
                <div class="col col-lg-10 col-sm-8 col-md-8">
                    <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
                </div>
            </div>
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>

         <!-- Phone Number -->
         <div class="mt-4">
            <x-input-label for="phone" :value="__('Phone Number (رقم الهاتف)')" />
            <x-text-input id="phone" class="block mt-1 w-full" type="text" name="phone" :value="old('phone')" required autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('phone')" class="mt-2" />
        </div> 

        <!-- Address -->
        <div class="mt-4">
            <x-input-label for="address" :value="__('Address in UAE (العنوان في الإمارات العربية المتحدة)')" />
            <x-textarea-input id="address" rows="5" class="block mt-1 w-full" name="address" :value="old('address')" required autocomplete="username" />
            <x-input-error :messages="$errors->get('address')" class="mt-2" />
        </div>


    </div>
    <div class="col">
        <!-- Signature -->
        <div class="mt-4 mt-lg-0 mt-xl-0">
            <x-input-label for="signature" :value="__('Your Signature')" />
            <input id="signature" class="form-control rounded border-primary mt-1 w-100" type="file" name="signature" :value="old('signature')" autofocus autocomplete="signature" />
            <x-input-label for="signature" :value="__('This signature will be embedded on your Applications')" />
            <x-input-label for="signature" :value="__('Type: jpeg / png, size min: 100KB max: 2MB)')" />
            <x-input-error :messages="$errors->get('signature')" class="mt-2" />
        </div> 
        <!-- Email Address -->
        <div class="mt-4">
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" class="form-control mt-1 w-full" type="email" name="email" :value="old('email')" required autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>
        <!-- Password -->
        <div class="mt-4">
            <x-input-label for="password" :value="__('Password (8-15 Characters)')" />

            <x-text-input id="password" class="block mt-1 w-full"
                            type="password"
                            name="password"
                            required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password -->
        <div class="mt-4">
            <x-input-label for="password_confirmation" :value="__('Confirm Password')" />

            <x-text-input id="password_confirmation" class="block mt-1 w-full"
                            type="password"
                            name="password_confirmation" required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div>


    </div>
</div>
<div class="flex items-center justify-center mt-4">
    <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="{{ route('login') }}">
        {{ __('Already registered?') }}
    </a>

    <x-primary-button class="ms-4">
        {{ __('Register') }}
    </x-primary-button>
</div>

    </form>
</div>
</x-guest-layout>
