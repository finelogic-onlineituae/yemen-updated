<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    Please enter the OTP received in your registered email: <span style=" font-weight:bold;">{{auth()->user()->email}}</span>
                    <form method="POST">
                        @csrf
                        <x-input-label for="email_otp" :value="__('Enter your OTP Here:')" />
                        <x-text-input name="email_otp" type="text" required />
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
